# Go Inventory Management Module

Go Unit-1 Lab Assessment project.

## Included files
- `Go_Inventory_Management_Assignment.zip` — complete Go project source.
- `output-screenshot.png` — screenshot showing the program running and all three unit tests passing.

## Verification shown in the screenshot
- `go test -v`: TestAddItem, TestUpdateItem, and TestRemoveItem all PASS.
- `go run .`: Inventory Management menu starts and an item is added successfully.

## Run locally
1. Extract `Go_Inventory_Management_Assignment.zip`.
2. Open the extracted project folder in VS Code.
3. Run `go test -v` to execute unit tests.
4. Run `go run .` to start the inventory application.
